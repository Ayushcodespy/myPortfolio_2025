from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from products.models import Product
from customers.models import Customer
from billing.models import Invoice

@login_required
def dashboard(request):
    total_products = Product.objects.count()
    total_customers = Customer.objects.count()
    total_invoices = Invoice.objects.count()
    
    recent_invoices = Invoice.objects.all().order_by('-date')[:5]
    
    context = {
        'total_products': total_products,
        'total_customers': total_customers,
        'total_invoices': total_invoices,
        'recent_invoices': recent_invoices,
    }
    
    return render(request, 'core/dashboard.html', context)